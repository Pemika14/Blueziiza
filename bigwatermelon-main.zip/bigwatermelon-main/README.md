## 合成大西瓜
被西瓜整崩溃了,改动了一下代码，点击右上角的宝箱会切换水果。破坏游戏体验，谨慎尝试。
分支「default」是未改动代码
> ![image](https://github.com/JennerTien/bigwaterlemon/blob/main/1611557925872957.gif)
